# This script will create a list of male names
# pip install --upgrade names, pandas, pandas_datareader, scipy, matplotlib, pyodbc, pycountry, azure

### This looping operation will install required modules that are not already configured.
import importlib, os, sys
packages = ['numpy', 'pandas']
for package in packages:
  try:
    module = importlib.__import__(package)
    globals()[package] = module
  except ImportError:
    cmd = 'pip install --user ' + package
    os.system(cmd)
    module = importlib.__import__(package)

import names, random, datetime, numpy as np, pandas as pd, time, string, csv
rows = 1000000
firstnames = np.array([''.join(names.get_first_name(gender='male')) for _ in range(rows)])
firstname = pd.Series(firstnames).drop_duplicates().tolist()
firstname.sort()
inputzip = zip(firstname)
inputlist = list(zip(firstname))
df = pd.DataFrame(inputlist)
df.to_csv('malenames.txt',header=False,index=False)
