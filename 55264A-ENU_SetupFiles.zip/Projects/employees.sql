IF NOT EXISTS (SELECT * FROM sys.symmetric_keys WHERE name LIKE '%DatabaseMasterKey%') CREATE MASTER KEY ENCRYPTION BY PASSWORD='Pa$w0rdPa$w0rd' 
GO
IF NOT EXISTS (SELECT * FROM sys.database_credentials WHERE name LIKE '%CRD_BLOB%') CREATE DATABASE SCOPED CREDENTIAL CRD_BLOB WITH IDENTITY = 'SHARED ACCESS SIGNATURE',SECRET = 'crbHW9J3IdunYpjOsUQGY1yrDvMEG410+nBGX7GQ47iTZRpF0wov60c5cuKDnXuRmQSXayULfQxQV8c4RVMSdA=='
GO
IF NOT EXISTS (SELECT * FROM sys.external_data_sources WHERE name LIKE '%EDS_BLOB%') CREATE EXTERNAL DATA SOURCE EDS_BLOB WITH (TYPE = BLOB_STORAGE,LOCATION = 'https://in151209sa.blob.core.windows.net/55264a',CREDENTIAL = CRD_BLOB)
GO
IF OBJECT_ID('dbo.employees', 'U') IS NOT NULL DROP TABLE dbo.employees
GO 
CREATE TABLE dbo.employees ([EmployeeID] INT, [LastName] NVARCHAR(50), [FirstName] NVARCHAR(50), [DateOfBirth] Date, [HireDate] Date, [Salary] Decimal(18,4), [LocationID] INT, [DepartmentID] INT)
GO
BULK INSERT dbo.employees 
FROM 'employees.csv' 
WITH 
(  
    DATA_SOURCE = 'EDS_BLOB', 
    FORMAT = 'CSV', 
    CODEPAGE = 65001, 
    FIRSTROW = 2, 
    TABLOCK 
)
