# This script uses the Natural Language Toolkit (nltk) to guess the gender of an employee
# pip install --upgrade nltk, pandas, pandas_datareader, names, scipy, matplotlib, pyodbc, pycountry, azure

### This looping operation will install required modules that are not already configured.
### import importlib can be used to load existing packages or scripts you create yourself (e.g. load myscript.py using "import myscript")
import importlib, os, sys
packages = ['numpy', 'pandas','nltk']
for package in packages:
  try:
    module = importlib.__import__(package)
    globals()[package] = module
  except ImportError:
    cmd = 'pip install --user ' + package
    os.system(cmd)
    module = importlib.__import__(package)

import pandas as pd
from nltk.classify import NaiveBayesClassifier
from nltk.corpus import names
nltk.download('names')

def find_gender(word):
  return {'last_letter': word[-1]}

names = ([(name, 'male') for name in names.words('male.txt')] + [(name, 'female') for name in names.words('female.txt')])
# malefilepath = os.getcwd() + '\\' + 'malenames.txt'
# femalefilepath = os.getcwd() + '\\' + 'femalenames.txt'
# names = ([(name, 'male') for name in names.words(malefilepath)] + [(name, 'female') for name in names.words(femalefilepath)])

featuresets = [(find_gender(n), g) for (n,g) in names] 
train_set = featuresets
classifier = nltk.NaiveBayesClassifier.train(train_set) 

employees = pd.read_csv('employees.csv')
gender = list()
firstname = employees.FirstName

for index, row in employees.iterrows():
  gender.append(classifier.classify(find_gender(row["FirstName"])))

inputlist = list(zip(firstname,gender))
df = pd.DataFrame(inputlist)
df.to_csv('employeegender.csv',index=False,header=["FirstName","Gender"])





