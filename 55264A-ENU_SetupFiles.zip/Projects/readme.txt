Place classroom and personal project files in this folder.

Save and use them for your own projects after the class.

For advanced students who want to do additional projects after the class, check with your instructor for additional options from this course.
