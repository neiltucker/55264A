# This script uses the sklearn module to guess the gender of an employee
# pip install --upgrade sklearn, pandas, pandas_datareader, names, scipy, matplotlib, pyodbc, pycountry, azure

### This looping operation will install required modules that are not already configured.
import importlib, os, sys
packages = ['numpy', 'pandas','sklearn']
for package in packages:
  try:
    module = importlib.__import__(package)
    globals()[package] = module
  except ImportError:
    cmd = 'pip install --user ' + package
    os.system(cmd)
    module = importlib.__import__(package)

import numpy as np, pandas as pd, csv
from sklearn import tree

### Read employees.csv file
df = pd.read_csv('employees.csv')

dtc = tree.DecisionTreeClassifier()
firstname = source.firstname
gender = source.gender
dtctrain = dtc.fit(firstname,gender)

prediction = dtc.predict
