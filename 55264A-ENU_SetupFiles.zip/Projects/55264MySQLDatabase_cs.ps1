﻿### Create Azure MySQL Server & Database using the Azure Cloud Shell (cs)
### Configure Objects & Variables
Set-StrictMode -Version 2.0
$SubscriptionName = (Get-AzureRMSubscription)[0].Name                                 # Replace with the name of your preferred subscription
$CloudDriveMP = (Get-CloudDrive).MountPoint
If (-NOT (Test-Path "F:")) {New-PSDrive -Name "F" -PSProvider "FileSystem" -Root $CloudDriveMP} Else {Write-Output "The F: drive already exists."}
$WorkFolder = "/home/$env:USER/clouddrive/labfiles.55264a/projects/"
If (-NOT (Test-Path $WorkFolder)) {New-Item -ItemType Directory -Path $WorkFolder} Else {Write-Output "$WorkFolder already exists."}
Set-Location $WorkFolder
$ExternalIP = ((Invoke-WebRequest -URI IPv4.Icanhazip.com -UseBasicParsing).Content).Trim()                                          # You may substitute with the Internet IP of your computer
# $ExternalIP = ((Invoke-WebRequest -Uri checkip.dyndns.org -UseBasicParsing).ParsedHtml.body.innerHtml -replace '^\D+').Trim()        # You may substitute with the Internet IP of your computer
If (Get-Module -ListAvailable -Name SQLServer) {Write-Output "SQLServer module already installed" ; Import-Module SQLServer} Else {Install-Module -Name SQLServer -Force ; Import-Module -Name SQLServer}
$SQLLogin1 = "sqllogin1"
$Password = 'Pa$$w0rdPa$$w0rd'
$PW = Write-Output $Password | ConvertTo-SecureString -AsPlainText -Force        # Password for SQL Database server
$SQLCredentials =  (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $SQLLogin1, $PW)
$Location = "EASTUS"
$DataLocation = "EASTUS"   				        	  # Verify that this location supports the creation of MySQL Server objects
$NamePrefix = "in" + (Get-Date -Format "HHmmss")       # Replace "in" with your initials.  Date information is added in this example to help make the names unique
$ResourceGroupName = $NamePrefix.ToLower() + "rg"
$StorageAccountName = $NamePrefix.ToLower() + "sa"     # Must be lower case
$MySQLServerName = 'ms' + $NamePrefix
$MySQLServerFQDN = $MySQLServerName + '.mysql.database.azure.com'
$DefaultDatabase= 'mysql'
$MySQLDB = 'mysqldb1'
$SQLLogin1 = "SQLLogin1"
$SQLLogin1UPN = $SQLLogin1 + "@" + $MySQLServerName
$Password = 'Pa$$w0rdPa$$w0rd'
$SecurePassword = ConvertTo-SecureString -AsPlainText $Password -Force
$MySQLCredentials =  (New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $SQLLogin1UPN, $SecurePassword)
$MySQLConnectionString = "Server=$MySQLServerFQDN;Port=3306;Database=$DefaultDatabase;Uid=$SQLLogin1UPN;Pwd=$Password;SslMode=Required;"
$SAShare = "55264a"                                    # Must be lower case
$TMPData = $WorkFolder + "employees.tmp"
$SQLData = $WorkFolder + "employees.sql"
$CustomerCSV = $WorkFolder + "customer.csv"
# Manually configured Variables
$ResourceGroupNameAAD = "azad55264rg"

### Log start time of script
$logFilePrefix = "55264AzureDatabase" + (Get-Date -Format "HHmm") ; $logFileSuffix = ".txt" ; $StartTime = Get-Date
"Create Azure Server and Database"   >  $WorkFolder$logFilePrefix$logFileSuffix
"Start Time: " + $StartTime >> $WorkFolder$logFilePrefix$logFileSuffix

### Login to Azure
# Connect-AzureRmAccount
$Subscription = Get-AzureRmSubscription -SubscriptionName $SubscriptionName | Set-AzureRMContext
Register-AzureRmResourceProvider -ProviderNamespace Microsoft.SQL

### Create Resource Group, Storage Account & Storage Account Share
New-AzureRMResourceGroup -Name $ResourceGroupName  -Location $Location
New-AzureRMStorageAccount -ResourceGroupName $ResourceGroupName -Name $StorageAccountName -Location $Location -Type Standard_RAGRS
$StorageAccountKey = (Get-AzureRmStorageAccountKey -ResourceGroupName $ResourceGroupName -Name $StorageAccountName)[0].Value
$StorageAccountContext = New-AzureStorageContext -StorageAccountName $StorageAccountName -StorageAccountKey $StorageAccountKey
$BlobContainer = New-AzureStorageContainer -Name $SAShare.ToLower() -Context $StorageAccountContext -Permission Container -Verbose
$BlobLocation = $BlobContainer.cloudblobcontainer.Uri.AbsoluteUri
Get-ChildItem -File $WorkFolder"employees.*" | Set-AzureStorageBlobContent -Container $SAShare -Context $StorageAccountContext -Force

### Create MySQL Server and Database (We will use Azure CLI for this part of the lab)
# az extension add --name rdbms          # This option is sometimes required for MySQL commands to work.  Ignore any error messages it may generate and continue.
$MySQLServerInstance = az mysql server create -n $MySQLServerName -g $ResourceGroupName -l $DataLocation  -u $SQLLogin1 -p $Password --ssl-enforcement Enabled --sku-name "GP_GEN5_2" # (The --sku-name parameter is sometimes required for setting up the server.  If the command fails, try disabling that parameter.)
az mysql server list --resource-group $ResourceGroupName --output table
az mysql db list -g $ResourceGroupName -s $MySQLServerName | ConvertFrom-Json | Format-Table Name, ResourceGroup, Type

### Configure MySQL Server Firewall
az mysql server firewall-rule create -s $MySQLServerName -g $ResourceGroupName -n "ClientIP1" --start-ip-address $ExternalIP --end-ip-address $ExternalIP
az mysql server firewall-rule create -s $MySQLServerName -g $ResourceGroupName -n "AllowAllWindowsAzureIps" --start-ip-address 0.0.0.0 --end-ip-address 0.0.0.0

### Install MySQL Python Connector  (Not needed for lab exercise but useful for Python developers.  Might require a virtual environment (virtualenv).)
# pip install mysql-connector

### Install MySQL Connector.  Check the web-site (https://dev.mysql.com/downloads/connector/net/) for later versions.
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$MySQLConnectorDownloadFile = $WorkFolder + "mysql-connector-net-8.0.11.msi"
$MySQLConnectorLogFile = $WorkFolder + "MySQLConnectorInstall.log"
$MySQLConnectorURL = "https://dev.mysql.com/get/Downloads/Connector-Net/mysql-connector-net-8.0.11.msi"
(New-Object System.Net.WebClient).DownloadFile($MySQLConnectorURL, $MySQLConnectorDownloadFile)
Start-Process msiexec.exe -Wait -ArgumentList "/I $MySQLConnectorDownloadFile /Passive ACCEPT_EULA=1 /log $MySQLConnectorLogFile"
Start-Sleep 15

### Install MySQL PowerShell Module
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$MySQLModuleFile = $WorkFolder + "MySQLModule.zip"
Get-ChildItem $WorkFolder | Where-Object {$_.Name -eq "MySQLModule.zip"} | Remove-Item -Force
Get-ChildItem -Recurse $PowerShellModuleFolder | Where-Object {$_.Name -eq "mysql"} | Remove-Item -Recurse -Force
Get-ChildItem -Recurse $PowerShellModuleFolder | Where-Object {$_.Name -eq "mysql-master"} | Remove-Item -Recurse -Force
Invoke-WebRequest -URI https://github.com/adbertram/MySQL/archive/master.zip -OutFile $MySQLModuleFile
Expand-Archive -Path $MySQLModuleFile -DestinationPath $PowerShellModuleFolder
Rename-Item -Path "$PowerShellModuleFolder\MySQL-Master" -NewName "MySQL"
Get-ChildItem -Recurse -File "$PowerShellModuleFolder\MySQL" | Unblock-File
Import-Module -Name MySQL
Start-Sleep 15

### Create and Query Table   (SSMS can be used to manage MySQL Servers by creating Linked Server connections)
Connect-MySQLServer -Credential $MySQLCredentials -ComputerName $MySQLServerFQDN -Database $DefaultDatabase
Invoke-MySqlQuery -Connection $MySQLConnectionString -Query "Create Database $MySQLDB;"
Invoke-MySqlQuery -Connection $MySQLConnectionString -Query "Show Databases;"
$MySQLConnectionString = "Server=$MySQLServerFQDN;Port=3306;Database=$MySQLDB;uid=$SQLLogin1UPN;Pwd=$Password;SslMode=Required;"
Connect-MySQLServer -Credential $MySQLCredentials -ComputerName $MySQLServerFQDN -Database $MySQLDB
Invoke-MySqlQuery -Connection $MySQLConnectionString -Query "CREATE TABLE employees (EmployeeID INT, LastName NVARCHAR(50), FirstName NVARCHAR(50), DateOfBirth Date, HireDate Date, Salary Decimal(18,4), LocationID INT, DepartmentID INT);"
Invoke-MySqlQuery -Connection $MySQLConnectionString -Query "Show Tables;"
# Format Input File for "Insert Into" Statement
$employeesCSVFile = $WorkFolder + "employees.csv"
New-Item -ItemType "File" $WorkFolder"employees.imp" -ErrorAction SilentlyContinue
$employeesIMPFile = $WorkFolder + "employees.imp"
$OpenBracket = "("
$CloseBracket = "),"
If (Get-ChildItem $employeesIMPFile) {Remove-Item $employeesIMPFile -Force}
Get-Content $employeescsvfile | Select-Object -Skip 1 | Foreach-Object {Write-Output $OpenBracket$_$CloseBracket} | Out-File -FilePath $employeesIMPFile -Append
$employeesIMPObject = Get-Content $employeesIMPFile
$employeesIMPObject[-1] = $employeesIMPObject[-1].Substring(0,$employeesIMPObject[-1].Length-1)   # Remove the last comma "," in the last record of the file.
$employeesIMPObject |  Out-File -FilePath $employeesIMPFile
# Use Import File (employees.imp) to insert records into employees table
Invoke-MySqlQuery -Connection $MySQLConnectionString -Query "Insert Into employees Values $employeesIMPObject"
Invoke-MySqlQuery -Connection $MySQLConnectionString -Query "Select * from employees;" | Format-Table -AutoSize

### Log VM Information and delete the Resource Group
"Azure MySQL Server Name :  " + $MySQLServerFQDN >> $WorkFolder$logFilePrefix$logFileSuffix
"Resource Group Name     :  " + $ResourceGroupName + "   # Delete the Resource Group to remove all Azure resources created by this script (e.g. Remove-AzureRMResourceGroup -Name $ResourceGroupName -Force)"  >> $WorkFolder$logFilePrefix$logFileSuffix
$EndTime = Get-Date ; $et = "55264AzureMySQL" + $EndTime.ToString("yyyyMMddHHmm")
"End Time:   " + $EndTime >> $WorkFolder$logFilePrefix$logFileSuffix
"Duration:   " + ($EndTime - $StartTime).TotalMinutes + " (Minutes)" >> $WorkFolder$logFilePrefix$logFileSuffix
Rename-Item -Path $WorkFolder$logFilePrefix$logFileSuffix -NewName $et$logFileSuffix
### Remove-AzureRMResourceGroup -Name $ResourceGroupName -Verbose -Force         # az group delete --name $ResourceGroupName
### Clear-Item WSMan:\localhost\Client\TrustedHosts -Force
### pip install --upgrade pandas, pandas_datareader, scipy, matplotlib, pyodbc, pycountry, azure
### Import-Module servermanager
### Add-WindowsFeature telnet-client
### telnet $MySQLServerFQDN 3306
