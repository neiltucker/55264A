echo "Create a virtual environment to use python resources on machines where root access is not available."
echo "Virtual environments are also useful for creating unique environments for different apps."
echo "Your personal user environment (python3 -m pip install --user <application>) can also be used to configure the environment when elevated access is required."
echo "On systems that support multiple versions of python, make sure the default version is 3.X or add an alias that maps python to python3 (e.g. alias python=python3)."
pip install --upgrade --user pip
# sudo apt-get install python3-venv -y
python3 -m venv ~/venv1
source ~/venv1/bin/activate
cd ~/venv1
pip install --upgrade pip
python3 -m pip install --upgrade pandas
python3 -m pip install --upgrade scipy
python3 -m pip install --upgrade matplotlib
python3 -m pip install --upgrade azure
# Examples of user environment configuration of python modules
# python3 -m pip install --user --upgrade pandas
# python3 -m pip install --user --upgrade scipy
# python3 -m pip install --user --upgrade matplotlib
# python3 -m pip install --user --upgrade azure
deactivate

