set-executionpolicy bypass
import-module servermanager
