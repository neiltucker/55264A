# Configure DNS Client
$DNSClient = GWMI Win32_networkAdapterConfiguration
$dnsclient.setDNSDomain("contoso.com")
$dnsclient.setdnsserversearchorder("192.168.10.100")

# Configure Firewall
Netsh AdvFirewall Firewall Set Rule Group="File And Printer Sharing" New Enable=Yes