$Key=(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24)
$DomainUser = "Contoso\Admin1"
$DomainPassword = Cat $env:workfolder"CLX\password.txt" | ConvertTo-SecureString -Key $Key
$DomainCredentials = New-Object �TypeName System.Management.Automation.PSCredential �ArgumentList $DomainUser, $DomainPassword
Remove-Computer -Credential $DomainCredentials -Verbose -PassThru -Force
reg import $env:workfolder"CLX\AutoLogonDisable.reg"
Shutdown /r /t 10
