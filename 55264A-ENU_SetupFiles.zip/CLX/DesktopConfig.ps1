#   IE Configuration
reg import $env:workfolder"CLX\ie.reg"
$ASKey1 = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
$ASKey2 = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
Set-ItemProperty -Path $ASKey1 -Name "IsInstalled" -Value 0
Set-ItemProperty -Path $ASKey2 -Name "IsInstalled" -Value 0

#   Configure Windows Explorer Settings
$VarWindowsExplorer = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced'
Set-ItemProperty $VarWindowsExplorer AlwaysShowMenus 1 -Force
Set-ItemProperty $VarWindowsExplorer FolderContentsInfoTip 1 -Force
Set-ItemProperty $VarWindowsExplorer Hidden 1 -Force
Set-ItemProperty $VarWindowsExplorer HideDrivesWithNoMedia 0 -Force
Set-ItemProperty $VarWindowsExplorer HideFileExt 0 -Force
Set-ItemProperty $VarWindowsExplorer IconsOnly 0 -Force
Set-ItemProperty $VarWindowsExplorer ShowSuperHidden 0 -Force
Set-ItemProperty $VarWindowsExplorer ShowStatusBar 1 -Force

#   Configure Desktop Settings
$shell = New-Object -ComObject WScript.Shell
$Location = [System.Environment]::GetFolderPath('Desktop')
$Computer = $shell.CreateShortcut("$Location\ $env:ComputerName.lnk")
$Computer.TargetPath = "Explorer.exe"
$Computer.IconLocation = "imageres.dll,104"
$Computer.HotKey = "CTRL+ALT+E"
$Computer.Save()
$PowerShell = $shell.CreateShortcut("$Location\ PowerShell.lnk")
$PowerShell.TargetPath = "PowerShell.exe"
$PowerShell.IconLocation = "PowerShell.exe"
$PowerShell.HotKey = "CTRL+ALT+P"
$PowerShell.Save()
$PowerShell_ISE = $shell.CreateShortcut("$Location\ PowerShell_ISE.lnk")
$PowerShell_ISE.TargetPath = "PowerShell_ise.exe"
$PowerShell_ISE.IconLocation = "powershell_ise.exe"
$PowerShell_ISE.HotKey = "CTRL+ALT+I"
$PowerShell_ISE.Save()
$CMD = $shell.CreateShortcut("$Location\Command Prompt.lnk")
$CMD.TargetPath = "cmd.exe"
$CMD.IconLocation = "cmd.exe"
$CMD.HotKey = "CTRL+ALT+C"
$CMD.Save()
$CMD = $shell.CreateShortcut("$Location\Internet Explorer.lnk")
$CMD.TargetPath = "C:\Program Files\Internet Explorer\iexplore.exe"
$CMD.IconLocation = "C:\Program Files\Internet Explorer\iexplore.exe"
$CMD.HotKey = "CTRL+ALT+W"
$CMD.Save()

### Install Modules used in Azure
If (Get-PackageProvider -Name NuGet) {Write-Output "NuGet PackageProvider already installed."} Else {Install-PackageProvider -Name NuGet -Force}
If (Get-Module -ListAvailable -Name PowerShellGet) {Write-Output "PowerShellGet module already installed"} Else {Find-Module PowerShellGet -IncludeDependencies | Install-Module -Force}
If (Get-Module -ListAvailable -Name AzureRM) {Write-Output "AzureRM module already installed" ; Import-Module AzureRM} Else {Find-Module AzureRM -IncludeDependencies | Install-Module ; Import-Module -Name AzureRM}
If (Get-Module -ListAvailable -Name SQLServer) {Write-Output "SQLServer module already installed" ; Import-Module SQLServer} Else {Install-Module -Name SQLServer -AllowClobber -Force ; Import-Module -Name SQLServer}
If (Get-Module -ListAvailable -Name AzureAD) {Write-Output "AzureAD module already installed" ; Import-Module AzureAD} Else {Install-Module AzureAD -Force ; Import-Module -Name AzureAD}

