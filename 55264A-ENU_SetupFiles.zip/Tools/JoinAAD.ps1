$WorkFolder = "c:\labfiles.55264a\"
[Environment]::SetEnvironmentVariable("WORKFOLDER", $WorkFolder)
$DomainName = "josephsingletonhotmail.onmicrosoft.com"
$DomainUser = 'aadlogin2@josephsingletonhotmail.onmicrosoft.com'
$DomainPassword = 'Pa$$w0rdPa$$w0rd' | ConvertTo-SecureString -AsPlainText -Force        
$Credentials = New-Object �TypeName System.Management.Automation.PSCredential �ArgumentList $DomainUser, $DomainPassword
Add-Computer -DomainName $DomainName -Verbose -PassThru -Credential $Credentials 
$Subscription = Add-AzureRMAccount -Credential $Credentials
# Shutdown /r /t 10