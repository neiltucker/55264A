import pandas as pd
csv_file = 'c:\\labfiles.55264a\\tools\\goldprices.csv'
csvdata = pd.read_csv(csv_file, index_col=0, parse_dates=True)
csvdata
csvdata.to_csv('c:\\labfiles.55264a\\tools\\goldprices2.csv')
csvdata.to_csv(path_or_buf='c:\\labfiles.55264a\\tools\\goldprices2.tsv',sep='\t')

