# importlib package must be installed for this script to work   (pip install importlib)
import importlib, os
packages = ['pymysql', 'azure', 'azure.mgmt', 'azure.mgmt.rdbms', 'azure.mgmt.rdbms.mysql', 'azure.common', 'azure.storage', 'azure.storage.common', 'azure.storage.blob', 'azure.storage.file', 'azure.cli', 'azure.cli.core', 'pyodbc', 'mysql.connector']
for package in packages:
  try:
    module = importlib.__import__(package)
    print(package, ' package was imported.')
    globals()[package] = module
  except ImportError:
    cmd = 'pip install --user ' + package
    print('Please wait.  Package is being installed: ', package)
    os.system(cmd)
    module = importlib.__import__(package)
    print(package, ' package was imported.')

# These modules are used for authenticating to Azure, using resources and managing storage.  
# Install them if they are not already on the system:
import datetime, os, requests, pyodbc, csv, pymysql, mysql.connector
from mysql.connector.constants import ClientFlag
from azure.cli.core import get_default_cli
from azure.common.client_factory import get_client_from_cli_profile
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.storage import StorageManagementClient
from azure.storage.common import CloudStorageAccount
from azure.storage.file import FileService
from azure.storage.blob import PublicAccess
from azure.mgmt.rdbms.mysql import MySQLManagementClient
from azure.mgmt.rdbms.mysql.models import ServerForCreate, ServerPropertiesForDefaultCreate, ServerVersion, SslEnforcementEnum
from requests import get

# Configure Clients for Managing Resources
resource_client = get_client_from_cli_profile(ResourceManagementClient)
storage_client = get_client_from_cli_profile(StorageManagementClient)
mysql_client = get_client_from_cli_profile(MySQLManagementClient)

# Configure Variables
externalip = requests.get('https://ipapi.co/ip/').text
homedirectory = os.path.expanduser("~")
workfolder = os.path.normpath(homedirectory + '/clouddrive/labfiles.55264a')
os.chdir(workfolder)
nameprefix = 'np' + (datetime.datetime.now()).strftime('%H%M%S')     # replace 'np' with your initials
externalip=get('https://ipapi.co/ip/').text
RESOURCE_GROUP_NAME = nameprefix + 'rg'
STORAGE_ACCOUNT_NAME = nameprefix + 'sa'
LOCATION = 'northeurope'
sharename = '55264a'
filename = 'input.csv'
MYSQL_SERVER_NAME = nameprefix + 'sql'
MYSQL_FQDN = MYSQL_SERVER_NAME + '.mysql.database.azure.com'
MYSQL_DB_NAME = nameprefix + 'db'
USERNAME = 'sqllogin1'
USERLOGIN = USERNAME + '@' + MYSQL_SERVER_NAME
USERPASSWORD = 'Password!234'

def main():
    # Create the Resource Group and Storage Account.  Use Azure Portal to examine their properties before deleting them.
    global resource_group, storage_account
    resource_group_params = {'location':LOCATION}
    global resource_group, storage_account
    resource_group = resource_client.resource_groups.create_or_update(RESOURCE_GROUP_NAME, resource_group_params)
    storage_account = storage_client.storage_accounts.create(RESOURCE_GROUP_NAME, STORAGE_ACCOUNT_NAME, {'location':LOCATION,'kind':'storage','sku':{'name':'standard_ragrs'}})
    storage_account.wait()

main()

def shares(sharename):
    # Create Container and Share
    global sak, storage_account_key, blob_service, blob_share, file_service, file_share
    sak = storage_client.storage_accounts.list_keys(RESOURCE_GROUP_NAME, STORAGE_ACCOUNT_NAME)
    storage_account_key = sak.keys[0].value
    cloudstorage_client =  CloudStorageAccount(STORAGE_ACCOUNT_NAME,storage_account_key)
    blob_service = cloudstorage_client.create_block_blob_service()
    blob_share = blob_service.create_container(sharename,public_access=PublicAccess.Container)
    file_service = FileService(account_name=STORAGE_ACCOUNT_NAME, account_key=storage_account_key)
    file_share = file_service.create_share(sharename)

shares(sharename)

# Copy Setup Files to Container and Share
blob_service.create_blob_from_path(sharename,filename,filename,)
file_service.create_file_from_path(sharename,'',filename,filename,)

# Create Azure MySQL Server using azure.cli.core
get_default_cli().invoke(['mysql', 'server', 'create', '--resource-group', RESOURCE_GROUP_NAME, '--name', MYSQL_SERVER_NAME, '--location', LOCATION, '--admin-user', USERNAME, '--admin-password', USERPASSWORD, '--ssl-enforcement', 'Disabled', '--sku-name', 'GP_Gen5_2', '--version', '5.7'])
get_default_cli().invoke(['mysql', 'server', 'firewall-rule', 'create', '-s', MYSQL_SERVER_NAME, '-g', RESOURCE_GROUP_NAME, '-n', 'ClientIP1', '--start-ip-address', externalip, '--end-ip-address', externalip])
get_default_cli().invoke(['mysql', 'server', 'firewall-rule', 'create', '-s', MYSQL_SERVER_NAME, '-g', RESOURCE_GROUP_NAME, '-n', 'AllowAllWindowsAzureIps', '--start-ip-address', '0.0.0.0', '--end-ip-address', '0.0.0.0'])

# Create Azure MySQL Database using azure.cli.core
get_default_cli().invoke(['mysql', 'db', 'create', '-g', RESOURCE_GROUP_NAME, '-s', MYSQL_SERVER_NAME, '-n', MYSQL_DB_NAME])

# Setup MySQL Connection
conn = pymysql.connect(host=MYSQL_FQDN, port=3306, user=USERNAME, passwd=USERPASSWORD, db=MYSQL_DB_NAME)
cur = conn.cursor()
cur.execute("SELECT * FROM users")




