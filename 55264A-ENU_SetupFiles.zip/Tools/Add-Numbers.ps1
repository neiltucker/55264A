﻿$integer1 = 10
$integer2 = 20

function Add-Numbers($integer1, $integer2) {
# Param ([int]$integer1, [int]$integer2)
$integer3 = $integer1 + $integer2
$Global:integer4 = $integer1 + $integer2 + $integer3
Write-Host $integer1 " plus " $integer2 " = " $integer3
Write-Host $integer1 " plus " $integer2 " plus " $integer3 " = " $integer4
return $integer3
}

$output = Add-Numbers 5 10

Write-Host "The integer3 variable is: " $integer3      #  What output does this variable have?
Write-Host "The integer4 variable is: " $integer4      #  What output does this variable have?