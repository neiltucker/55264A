﻿$WorkFolder = "c:\labfiles.55264a\"
# [Environment]::SetEnvironmentVariable("WORKFOLDER", $WorkFolder,"Machine")
Set-Location $WorkFolder
$OldText = ' = "Azure Subscription"'
$NewText = ' = "Azure Pass"'
$FileList = Get-ChildItem -Path $WorkFolder"*.ps1"
$FileList | ForEach-Object {
(Get-Content $_.Name) -Replace $OldText , $NewText | Out-File -FilePath $_.Name -Force
}
