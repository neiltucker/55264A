# Create a Resource Group and Storage Account in Microsoft Azure
# Resource Groups are used to store and organize resources in Azure.
# Storage Accounts are used to store & share your data & files in different formats.
# Run this code from a python session on the Azure Cloud Shell.
# After the resource group and storage account are created, verify their configuration in the Azure Portal (http://portal.azure.com)
# Continue with the creation of your other resources then delete the resource group once you are finished with them.

'''
pip install --user azure-mgmt azure-common azure-storage azure-storage-common azure-cli azure-cli-core pyodbc psql-connector-python azure-mgmt-resource azure.mgmt.rdbms azure-mgmt-sql
pip list
python
'''

### This looping operation will install the modules not already configured.
# importlib package must be installed for this script to work   (pip install importlib)
import importlib, os, sys, datetime
packages = ['azure', 'azure.mgmt', 'azure.mgmt.rdbms', 'azure.mgmt.rdbms.postgresql', 'azure.common', 'azure.storage', 'azure.storage.common', 'azure.storage.blob', 'azure.storage.file', 'azure.cli', 'azure.cli.core', 'pyodbc']
for package in packages:
  try:
    module = importlib.__import__(package)
    print(package, ' package was imported.')
    globals()[package] = module
  except ImportError:
    cmd = 'pip install --user ' + package
    print('Please wait.  Package is being installed: ', package)
    os.system(cmd)
    module = importlib.__import__(package)
    print(package, ' package was imported.')

# These modules are used for authenticating to Azure, using resources and managing storage.  
# Install them if they are not already on the system:
import datetime, os, requests, pyodbc, csv
from azure.common.client_factory import get_client_from_cli_profile
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.storage import StorageManagementClient
from azure.storage.common import CloudStorageAccount
from azure.storage.file import FileService
from azure.storage.blob import PublicAccess
from azure.mgmt.sql import SqlManagementClient
from azure.mgmt.rdbms.postgresql import PostgreSQLManagementClient
from azure.mgmt.rdbms.postgresql.models import ServerForCreate, ServerPropertiesForDefaultCreate, ServerVersion

# Configure Clients for Managing Resources
resource_client = get_client_from_cli_profile(ResourceManagementClient)
storage_client = get_client_from_cli_profile(StorageManagementClient)
psql_client = get_client_from_cli_profile(PostgreSQLManagementClient)

# Configure Variables
externalip = requests.get('https://ipapi.co/ip/').text
homedirectory = os.path.expanduser("~")
workfolder = os.path.normpath(homedirectory + '/clouddrive/labfiles.55264a/')
os.chdir(workfolder)
nameprefix = 'np' + (datetime.datetime.now()).strftime('%H%M%S')     # replace 'np' with your initials
resource_group_name = nameprefix + 'rg'
storage_account_name = nameprefix + 'sa'
location = 'eastus'
sharename = '55264a'
filename = 'input.csv'
psql_name = nameprefix + 'psql'
psql_fqdn = psql_name + '.postgres.database.azure.com'
psql_db_name = nameprefix + 'db'
username = 'sqllogin1'
password = 'Password:123'

def main():
    # Create the Resource Group and Storage Account.  Use Azure Portal to examine their properties before deleting them.
    global resource_group, storage_account
    resource_group_params = {'location':location}
    global resource_group, storage_account
    resource_group = resource_client.resource_groups.create_or_update(resource_group_name, resource_group_params)
    storage_account = storage_client.storage_accounts.create(resource_group_name, storage_account_name, {'location':location,'kind':'storage','sku':{'name':'standard_ragrs'}})
    storage_account.wait()


main()

def shares(sharename):
    # Create Container and Share
    global storage_account_key, blob_service, blob_share, file_service, file_share
    sak = storage_client.storage_accounts.list_keys(resource_group_name, storage_account_name)
    storage_account_key = sak.keys[0].value
    cloudstorage_client =  CloudStorageAccount(storage_account_name,storage_account_key)
    blob_service = cloudstorage_client.create_block_blob_service()
    blob_share = blob_service.create_container(sharename,public_access=PublicAccess.Container)
    file_service = FileService(account_name=storage_account_name, account_key=storage_account_key)
    file_share = file_service.create_share(sharename)


shares(sharename)


# Copy Setup Files to Container and Share
blob_service.create_blob_from_path(sharename,filename,filename,)
file_service.create_file_from_path(sharename,'',filename,filename,)


def create_psql_server(psql_name):
    global psql_server
    psql_server = psql_client.servers.create(resource_group_name,psql_name,
        ServerForCreate(
        ServerPropertiesForDefaultCreate(
            administrator_login=username,
            administrator_login_password=password,
            version=ServerVersion.nine_full_stop_six,
        ),
        location=location
    )
)

psql_result = psql_server.result()


create_psql_server(psql_name)


# Delete Resource Group.  Deleting a resource group will also deleted all objects in it.
# delete_async_operation = resource_client.resource_groups.delete(resource_group_name)
# delete_async_operation.wait()

