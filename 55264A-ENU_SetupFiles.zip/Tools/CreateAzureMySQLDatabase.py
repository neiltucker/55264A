# Create a Resource Group and Storage Account in Microsoft Azure
# Resource Groups are used to store and organize resources in Azure.
# Storage Accounts are used to store & share your data & files in different formats.
# Run this code from a python session on the Azure Cloud Shell.
# After the resource group and storage account are created, verify their configuration in the Azure Portal (http://portal.azure.com)
# Continue with the creation of your other resources then delete the resource group once you are finished with them.

'''
pip install --user azure-mgmt azure-common azure-storage azure-storage-common azure-cli azure-cli-core pyodbc mysql-connector mysql-connector-python azure-mgmt-resource azure.mgmt.rdbms azure-mgmt-sql
pip list
python
'''

### This looping operation will install the modules not already configured.
# importlib package must be installed for this script to work   (pip install importlib)
import importlib, os, sys, datetime
packages = ['azure', 'azure.mgmt', 'azure.mgmt.rdbms', 'azure.mgmt.rdbms.mysql', 'azure.common', 'azure.storage', 'azure.storage.common', 'azure.storage.blob', 'azure.storage.file', 'azure.cli', 'azure.cli.core', 'pyodbc', 'mysql.connector', 'pymysql']
for package in packages:
  try:
    module = importlib.__import__(package)
    print(package, ' package was imported.')
    globals()[package] = module
  except ImportError:
    cmd = 'pip install --user ' + package
    print('Please wait.  Package is being installed: ', package)
    os.system(cmd)
    module = importlib.__import__(package)
    print(package, ' package was imported.')

# These modules are used for authenticating to Azure, using resources and managing storage.  
# Install them if they are not already on the system:
import datetime, os, requests, pyodbc, csv, mysql.connector
from mysql.connector.constants import ClientFlag
from azure.cli.core import get_default_cli
from azure.common.client_factory import get_client_from_cli_profile
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.storage import StorageManagementClient
from azure.storage.common import CloudStorageAccount
from azure.storage.file import FileService
from azure.storage.blob import PublicAccess
from azure.mgmt.rdbms.mysql import MySQLManagementClient
from azure.mgmt.rdbms.mysql.models import ServerForCreate, ServerPropertiesForDefaultCreate, ServerVersion, SslEnforcementEnum
from requests import get

# Configure Clients for Managing Resources
resource_client = get_client_from_cli_profile(ResourceManagementClient)
storage_client = get_client_from_cli_profile(StorageManagementClient)
mysql_client = get_client_from_cli_profile(MySQLManagementClient)

# Configure Variables
externalip = requests.get('https://ipapi.co/ip/').text
homedirectory = os.path.expanduser("~")
workfolder = os.path.normpath(homedirectory + '/clouddrive/labfiles.55264a')
os.chdir(workfolder)
nameprefix = 'np' + (datetime.datetime.now()).strftime('%H%M%S')     # replace 'np' with your initials
externalip=get('https://ipapi.co/ip/').text
RESOURCE_GROUP_NAME = nameprefix + 'rg'
STORAGE_ACCOUNT_NAME = nameprefix + 'sa'
LOCATION = 'northeurope'
sharename = '55264a'
filename = 'input.csv'
MYSQL_SERVER_NAME = nameprefix + 'sql'
MYSQL_FQDN = MYSQL_SERVER_NAME + '.mysql.database.azure.com'
MYSQL_DB_NAME = nameprefix + 'db'
USERNAME = 'sqllogin1'
USERLOGIN = USERNAME + '@' + MYSQL_SERVER_NAME
USERPASSWORD = 'Password!234'
connection_string = {'host':MYSQL_FQDN,'user':USERLOGIN,'password':USERPASSWORD,'database':MYSQL_DB_NAME}

def main():
    # Create the Resource Group and Storage Account.  Use Azure Portal to examine their properties before deleting them.
    global resource_group, storage_account
    resource_group_params = {'location':LOCATION}
    global resource_group, storage_account
    resource_group = resource_client.resource_groups.create_or_update(RESOURCE_GROUP_NAME, resource_group_params)
    storage_account = storage_client.storage_accounts.create(RESOURCE_GROUP_NAME, STORAGE_ACCOUNT_NAME, {'location':LOCATION,'kind':'storage','sku':{'name':'standard_ragrs'}})
    storage_account.wait()

main()

def shares(sharename):
    # Create Container and Share
    global sak, storage_account_key, blob_service, blob_share, file_service, file_share
    sak = storage_client.storage_accounts.list_keys(RESOURCE_GROUP_NAME, STORAGE_ACCOUNT_NAME)
    storage_account_key = sak.keys[0].value
    cloudstorage_client =  CloudStorageAccount(STORAGE_ACCOUNT_NAME,storage_account_key)
    blob_service = cloudstorage_client.create_block_blob_service()
    blob_share = blob_service.create_container(sharename,public_access=PublicAccess.Container)
    file_service = FileService(account_name=STORAGE_ACCOUNT_NAME, account_key=storage_account_key)
    file_share = file_service.create_share(sharename)

shares(sharename)

# Copy Setup Files to Container and Share
blob_service.create_blob_from_path(sharename,filename,filename,)
file_service.create_file_from_path(sharename,'',filename,filename,)

# Create Azure MySQL Server using azure.cli.core
get_default_cli().invoke(['mysql', 'server', 'create', '--resource-group', RESOURCE_GROUP_NAME, '--name', MYSQL_SERVER_NAME, '--location', LOCATION, '--admin-user', USERNAME, '--admin-password', USERPASSWORD, '--ssl-enforcement', 'Disabled', '--sku-name', 'GP_Gen5_2', '--version', '5.7'])
get_default_cli().invoke(['mysql', 'server', 'firewall-rule', 'create', '-s', MYSQL_SERVER_NAME, '-g', RESOURCE_GROUP_NAME, '-n', 'ClientIP1', '--start-ip-address', externalip, '--end-ip-address', externalip])
get_default_cli().invoke(['mysql', 'server', 'firewall-rule', 'create', '-s', MYSQL_SERVER_NAME, '-g', RESOURCE_GROUP_NAME, '-n', 'AllowAllWindowsAzureIps', '--start-ip-address', '0.0.0.0', '--end-ip-address', '0.0.0.0'])

# Create Azure MySQL Database using azure.cli.core
get_default_cli().invoke(['mysql', 'db', 'create', '-g', RESOURCE_GROUP_NAME, '-s', MYSQL_SERVER_NAME, '-n', MYSQL_DB_NAME])

# Create and Query a Table
cnx = mysql.connector.connect(**connection_string) 
cursor = cnx.cursor()
cursor.execute("DROP TABLE IF EXISTS employees;")
cnx.commit()
cursor.execute("CREATE TABLE employees (id nvarchar(50), lastname nvarchar(50), firstname nvarchar(50), hiredate nvarchar(50), hiretime nvarchar(50));")
cnx.commit()
cursor.execute("INSERT INTO employees (id,lastname,firstname,hiredate,hiretime) VALUES (%s,%s,%s,%s,%s);", (1,"williams","john","2018-06-28","12:30:00"))
cnx.commit()
cursor.execute("SELECT * FROM employees;")
rows = cursor.fetchall()
for row in rows: print("Row",cursor.rowcount, ":  ", row[2], row[1], " hired on ", row[3], " at ", row[4])

cnx.commit()
cursor.close()
cnx.close()

'''
LOAD DATA INFILE "/home/paul/clientdata.csv"
INTO TABLE CSVImport
COLUMNS TERMINATED BY ','
OPTIONALLY ENCLOSED BY '"'
ESCAPED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;
'''

# Delete Resource Group.  Deleting a resource group will also deleted all objects in it.
# delete_async_operation = resource_client.resource_groups.delete(RESOURCE_GROUP_NAME)
# delete_async_operation.wait()


'''
# Create Azure MySQL Server using azure.mgmt.rdbms.mysql
def create_mysql_server(MYSQL_SERVER_NAME):
    global mysql_server
    mysql_server = mysql_client.servers.create(resource_group_name=RESOURCE_GROUP_NAME, server_name=MYSQL_SERVER_NAME,
        ServerForCreate(
        ServerPropertiesForDefaultCreate(
            administrator_login=USERNAME,
            administrator_login_password=USERPASSWORD,
            version=ServerVersion.five_full_stop_seven,
            ssl_enforcement=SslEnforcementEnum.enabled,
        ),
        location=LOCATION
    )
)


mysql_result = mysql_server.result()

create_mysql_server(MYSQL_SERVER_NAME)
'''