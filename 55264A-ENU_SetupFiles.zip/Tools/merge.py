# Merge data from an employees and orders table using employeeid as the join field.
import pandas as pd
employees = pd.read_csv("employees.csv")
orders = pd.read_csv("orders.csv")
orders = orders.dropna(axis=0)
join = employees.merge(orders, on='EmployeeID')
join.to_csv("employees_orders.csv", index=False)

