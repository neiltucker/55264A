IF NOT EXISTS (SELECT * FROM sys.symmetric_keys WHERE name LIKE '%DatabaseMasterKey%') CREATE MASTER KEY ENCRYPTION BY PASSWORD='Pa$w0rdPa$w0rd' 
GO
IF NOT EXISTS (SELECT * FROM sys.database_credentials WHERE name LIKE '%CRD_BLOB%') CREATE DATABASE SCOPED CREDENTIAL CRD_BLOB WITH IDENTITY = 'SHARED ACCESS SIGNATURE',SECRET = 'I5zqbG+WNo9pPFx0L9GYMJLxS8QTHpa8ikdSP8KCmZaDSS8XDm/y3rVjzyeNgHb8INwHW6qjQBFsFyCxdYm8mg=='
GO
IF NOT EXISTS (SELECT * FROM sys.external_data_sources WHERE name LIKE '%EDS_BLOB%') CREATE EXTERNAL DATA SOURCE EDS_BLOB WITH (TYPE = BLOB_STORAGE,LOCATION = 'https://in194740sa.blob.core.windows.net/55247a',CREDENTIAL = CRD_BLOB)
GO
IF OBJECT_ID('dbo.orderdata', 'U') IS NOT NULL DROP TABLE dbo.orderdata
GO 
CREATE TABLE dbo.orderdata ([OrderID] INT, [CustomerID] NVARCHAR(10), [ManagerID] NVARCHAR(10), [Quantity] INT, [Price] Decimal(18,4), [Freight] Decimal(18,4), [OrderDate] Date, [ShippedDate] Date)
GO
BULK INSERT dbo.orderdata 
FROM 'orderdata.csv' 
WITH 
(  
    DATA_SOURCE = 'EDS_BLOB', 
    FORMAT = 'CSV', 
    CODEPAGE = 65001, 
    FIRSTROW = 2, 
    TABLOCK 
)
