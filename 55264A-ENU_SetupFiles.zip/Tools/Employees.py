# This script will create an "Employee Table" with employee names and employeeid numbers exported to a CSV file.
# Change the rows variable to control the number of rows exported.
# pip install --upgrade names, pandas, pandas_datareader, scipy, matplotlib, pyodbc, pycountry, azure

import names, random, numpy as np, pandas as pd, csv
rows = 1000
employeeid = np.array(range(1,rows+1))
lastname = np.array([''.join(names.get_last_name()) for _ in range(rows)])
firstname = np.array([''.join(names.get_first_name()) for _ in range(rows)])
inputzip = zip(employeeid,lastname,firstname)
inputlist = list(zip(employeeid,lastname,firstname))
df = pd.DataFrame(inputlist)
df.to_csv('employees.csv',index=False,header=["EmployeeID","LastName","FirstName"])
