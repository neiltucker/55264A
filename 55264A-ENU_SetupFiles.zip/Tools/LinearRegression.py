### Linear Regression operation to predict stock prices
### Modules needed for this script to perform properly
'''
pip install sklearn, scipy, matplotlib, numpy, pandas, pandas_datareader
'''

# Import Modules and configure variables
import csv, os, datetime, pandas as pd, numpy as np, matplotlib.pyplot as plt, pandas_datareader.data as web
from sklearn.linear_model import LinearRegression
start = datetime.date.today() - datetime.timedelta(365)
end = datetime.date.today() - datetime.timedelta(1)
next_month = end + datetime.timedelta(28)
next_month_timestamp = (pd.to_datetime(next_month)).timestamp()
datestring = datetime.datetime.today().strftime("%Y%m%d%H%M")
homedirectory = os.path.expanduser("~")
workfolder = os.path.normpath(homedirectory + '/clouddrive/labfiles.55264a/')
os.chdir(homedirectory)
os.getcwd()

# Get the data
wmt = web.DataReader("WMT", 'yahoo', start, end)
xom = web.DataReader("XOM", 'yahoo', start, end)
xomfile = datestring + '_' +' XOM' + '.csv'
xom.to_csv(xomfile,encoding='utf-8')
wmtfile = datestring + '_' +' WMT' + '.csv'
wmt.to_csv(wmtfile,encoding='utf-8')

# Format data and Prepare Model
xomdf = pd.read_csv(xomfile)
xomdf['Date'] = pd.to_datetime(xomdf['Date'])
# xomdf['Date'] = xomdf['Date'].map(datetime.datetime.toordinal)
dates = list(xomdf['Date'])
timestamps = []
prices = []
for timestamp, price in zip(xomdf['Date'],xomdf['Close']):
    timestamps.append([float(timestamp.timestamp())])
    prices.append(float(price))

linear_mod = LinearRegression()  
linear_mod.fit(timestamps,prices) 
predict_outcome = linear_mod.predict(next_month_timestamp)

# Chart Data
plt.scatter(dates,prices,color='blue')  
plt.plot(next_month,predict_outcome[0],color='red',linewidth=3) 
plt.scatter(next_month,predict_outcome[0],color='red') 
plt.grid()
plt.show()

