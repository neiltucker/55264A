#!/usr/bin/env python
# coding: utf-8

# # Lab 1, Exercise 1
# # Introduce Python variables, data types, operators and built-in commands
# 

# In[ ]:


print("Data Science is better than chocolate.")
var1 = "Data Science is better than chocolate or ice cream."
var1
print(var1)
type(var1)


# In[ ]:


integer1 = 5
string1 = "This is a string."
string2 = "  This is another string."
float1 = 5.5
integer2 = integer1 + 20
string3 = string1 + string2
string3
print("The first sixteen (16) characters in string3 are: ", string3[0:16])


# In[ ]:


help(str)


# In[ ]:


print("Add two integer values: ", integer1 + integer2)
print("Multiply two integer values: ", integer1 * integer2)
print("Concatenate two integer values: ", str(integer1) + str(integer2))


# In[ ]:


# Get information about the attributes of a variable
dir(integer1)


# In[ ]:


print("Enter two numbers to be added:")
n1 = input("Enter the first number:  ")
n2 = input("Enter the second number: ")
n3 = int(n1) + int(n2)
print(n1 + " plus " + n2 + " = ", n3)


# In[ ]:


sequence1 = (0, 10,20,30,40,50,60,70,80,90,100) ; list1 = list(sequence1) ; list1[0] = 1
print("sequence1 values: ", sequence1)
print("list1 values: ", list1)
print("list1 multiplied by 2: ", list1 * 2)
print("The number of values in the list is:", len(list1))
list1


# In[ ]:


# Sort the list in reverse order
print("The last value output is: ", _)
print("list1 sorted in reverse order is: ", sorted(list1,reverse=True))


# In[ ]:


list1 = [1,2,3,4,5]
list1.append(6)
print(list1)
list1[0] = 0
list1[2] = 4
print(list1)


# In[ ]:


string1 = "0000000Please remove the zeros from this string.0000000" ; print(string1.strip('0'))


# In[ ]:


# Will generate errors.  Comment out the lines that have errors to run successfully  
str1 = "Test string."
print("str1 is: ", str1)
# print(int(str1))       # Cannot convert text-based string to integer
tuple1 = (1,2,3,4,5)
# tuple1.append(6)       # Cannot append to tuple
list1 = [1,2,3,4,5]
list1.append(6)
print("The first three (3) values in list1 are: ", list1[0:3])
print("All the values in list1 are: ", list1)


# In[ ]:


dict1 = {'name':'Carlos Santiago','age':'43','phone':'123-456-789'}
print("The data type of the dict1 variable is: ",type(dict1))
print("The phone number is: ",dict1['phone'])
display(dict1.keys())
dict1.values()


# In[ ]:


# Run operating system commands using "!"
get_ipython().system(u'dir ')
get_ipython().system(u'pwd')
get_ipython().system(u'copy nul test.txt')


# In[ ]:


get_ipython().system(u'pip list')


# In[ ]:


get_ipython().system(u'pip install --upgrade azure-common')
get_ipython().system(u'pip install azure-storage')


# In[ ]:


get_ipython().magic(u'lsmagic')


# In[ ]:


get_ipython().run_cell_magic(u'bash', u'', u'pip show azure-common\npip show jupyter-client')


# In[ ]:


get_ipython().run_cell_magic(u'bash', u'  ', u'dir\npwd')


# In[ ]:


get_ipython().run_cell_magic(u'time', u'', u'string1 = "123456789"\nstring2 = "987654321"\nstring3 = "999999999"\ninteger1 = int(string1) * int(string2) * int(string3)\nprint(integer1)')


# In[ ]:


get_ipython().run_cell_magic(u'HTML', u'', u'<iframe width="560" height="315" src="https://www.youtube.com/embed/rcBpQ9fwNTY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>')


# In[ ]:


get_ipython().run_cell_magic(u'HTML', u'', u'<iframe width="560" height="315" src="https://www.youtube.com/embed/JWEhns28Cr4" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>')


# In[ ]:


get_ipython().run_cell_magic(u'HTML', u'', u'<iframe width="560" height="315" src="https://www.youtube.com/embed/evhpuRjHkjk" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>')


# In[ ]:


# Test arithmetic operators
print(2 ** 4)
print(2 * 4)
print(2 + 4)
print(2 - 4)
print(2 / 4)
print(2 // 4)
print(2 % 4)


# In[ ]:


# Test comparison operators
print(2 < 4)
print(2 > 4)
print(2 != 4)
print(2 == 4)
print(2 <= 4)
print(2 >= 4)


# In[ ]:


# Using help and dir
list1 = [82,8,23,97,92,44,17,39,11,12]
dir(list1)
help(list1.insert)
list1.insert(0,5)
help(list1.append)
list1.append(6)
help(list1.reverse)
list1.reverse()

