
# coding: utf-8

# # Lab 1, Exercise 1
# # Introduce Python variables, data types, operators and built-in commands
# 

# In[ ]:


### Create a variable that stores the statement "This is a test."
### Print the output of the variable
### Use a built-in command to verify the data type of the variable


# In[ ]:


### Create a variable that stores the integer value 10
### Create a variable that stores a float value of 10.5
### Create two string variables that store different sentences
### Create a variable that stores the values from the previous integer and float variables then print the output


# In[ ]:


### Create a variable that concatenates the values from the string variables in the previous cell then print the output
### Use the help command to get information about "str" and "int"
### Use the dir command to get information about one of the string and integer variables you created


# In[ ]:


### Use the input command to get two values 
### Add the values and print the result


# In[ ]:


### Create a list that stores 5 numbers in any order
### Print the values in the list
### Use the len command to verify the number of values in the list
### Add a new number to the list and then verify number of values again
### Multiply the list by two and print the result
### Sort and print the list in ascending and descending orders


# In[ ]:


### Create a tuple and a list that store the same 5 numbers
### Try appending a new number to the tuple and the list
### Print the tuple and the list


# In[ ]:


### Create a dictionary that stores an employee record containing his name, age and phone number
### Print the dictionary keys
### Print the dictionary values
### Print only the employees age 


# In[ ]:


### Without exiting jupyter, perform the following operations on the operating system
# Verify the name of the present working directory
# List all the files in the current directory
# Create an empty text file in the current directory
# List all packages installed with pip
# Install the azure-common package.  If it is already installed, upgrade it


# In[ ]:


### Use %lsmagic to list all the line and cell magics available in your jupyter session
### Use %%bash to perform the operating system tasks from the previous step
### Use %%html to display and play an online web-page or video


# In[ ]:


### Using two integer variables, perform the following arithmetic operations and print the results:
# Exponent (**)
# Multiplication (*)
# Addition (+)
# Subtraction (-)
# Division (/)
# Floor Division (//)
# Modulus (%)


# In[ ]:


### Using two integer variables, perform the following comparison operations and print the results:
# Greater Than (>)
# Less Than (<)
# Equal To (==)
# Not Equal To (!=)
# Greater Than or Equal To (>=)
# Less Than or Equal To (<=)


# In[ ]:


### Create a list of numbers and use the dir function to get information about the different attributes available
### Use the help function to get information about how to use the insert, append, count, sort and reverse attributess


# In[ ]:


### Download the notebook as a Python (py) file
### If time permits, run these commands again in a Python session on Azure Cloud Shell (http://shell.azure.com)
### Make a note of which commands work only in a jupyter notebook and not in a normal Python console
### List all builtin and installed modules available in your python session

