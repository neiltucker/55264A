#  Using your Microsoft Azure credentials, login to the Cloud Shell (http://shell.azure.com)
#  Test both the PowerShell and Bash shells by using the pwsh and bash commands respectively. 
#  For both PowerShell and Bash, verify the version of Python being used (python --version).  You may use either PowerShell or Bash for the following steps.
#  Upload this file to your home directory (cd ~) using the "Upload/Download Files" icon
#  Verify the file uploaded properly then open it using visual studio code (code Lab1_0.py).  Notice that the names are case-sensitive.
#  Without saving any changes, exit Visual Studio Code (Ctrl + Q)
#  Execute the Python script (python Lab1_0.py)
int1 = 5
int2 = 5+5
int3 = int1 + int2
print("Value of int3 is: ", int3)
str1 = "This is "
str2 = "a test."
str3 = str1 + str2
print("Value of str3 is: ", str3)
print("The data type of int3 is: ", type(int3))
print("The data type of str3 is: ", type(str3))
print("Convert int3 to a string: ", str(int3))
# prnt(int(str3))  This print command will generate an error.  Cannot convert non-numeric string to an integer.
tuple1 = (1,2,3,4,5)
print("tuple1 is: ", tuple1)
# tuple1.append(6)  This command will fail since you cannot append to an existing tuple.
list1 = [1,2,3,4,5]
print("List1 is: ",list1)
print("The length of list1 is: ", len(list1))
list1.append(6)
print("List1 is: ",list1)
print("The new length of list1 is: ", len(list1))
print("list1 * 2 is: ",list1*2)
input("Press Enter to continue ...")
input("Type 'q' to exit the following 'help' and 'dir' commands.  Press Enter to continue ...")

#  Get helpful details and attribute information for Python objects
help(list)
help(list1)
dir(list1)
list1.sort(reverse=True)
print("list1 reversed is: ", list1)
input("Press Enter to exit the script.")

#  open a Python console (python) and run the commands above interactively.  You may copy and paste from the script file.
#  Use the exit(), quit() or Ctrl+D commands to leave the python console.